﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace DataGridColumnsDemo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            SetUpPlanets();
        }

        public void SetUpPlanets()
        {
            DataContext = new List<Planet>
            {
                new Planet
                {
                    Name = "Mercury", Category = "Terrestrial",
                    GlobalMagneticField = true, HasRings = false, Moons = 0,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Mercury_(planet)")
                },
                new Planet
                {
                    Name = "Venus", Category = "Terrestrial",
                    GlobalMagneticField = false, HasRings = false, Moons = 0,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Venus")
                },
                new Planet
                {
                    Name = "Earth", Category = "Terrestrial",
                    GlobalMagneticField = true, HasRings = false, Moons = 1,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Earth")
                },
                new Planet
                {
                    Name = "Mars", Category = "Terrestrial",
                    GlobalMagneticField = false, HasRings = false, Moons = 0,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Mars")
                },
                new Planet
                {
                    Name = "Jupiter", Category = "Gas Giant",
                    GlobalMagneticField = true, HasRings = true, Moons = 67,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Jupiter")
                },
                new Planet
                {
                    Name = "Saturn", Category = "Gas Giant",
                    GlobalMagneticField = true, HasRings = true, Moons = 62,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Saturn")
                },
                new Planet
                {
                    Name = "Uranus", Category = "Ice Giant",
                    GlobalMagneticField = true, HasRings = true, Moons = 27,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Uranus")
                },
                new Planet
                {
                    Name = "Neptune", Category = "Ice Giant",
                    GlobalMagneticField = true, HasRings = true, Moons = 14,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Neptune")
                },
                new Planet
                {
                    Name = "Pluto", Category = "Dwarf Planet",
                    GlobalMagneticField = null, HasRings = false, Moons = 5,
                    MoreInfoUri = new Uri("http://en.wikipedia.org/wiki/Pluto")
                }
            };
        }

        private void DataGrid_Click(object sender, RoutedEventArgs e)
        {
            var hyperlink = e.OriginalSource as Hyperlink;
            if (hyperlink != null)
            {
                Process.Start(hyperlink.NavigateUri.ToString());
            }
        }
    }
}
