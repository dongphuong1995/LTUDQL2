﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample
{
    /// <summary>
    /// Interaction logic for Shadows.xaml
    /// </summary>
    public partial class Shadows : UserControl
    {
        public Shadows()
        {
            InitializeComponent();
        }
    }
}
