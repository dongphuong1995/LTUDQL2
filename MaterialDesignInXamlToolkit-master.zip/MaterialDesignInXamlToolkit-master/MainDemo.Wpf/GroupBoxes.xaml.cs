﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample
{
    /// <summary>
    /// Interaction logic for GroupBoxes.xaml
    /// </summary>
    public partial class GroupBoxes : UserControl
    {
        public GroupBoxes()
        {
            InitializeComponent();
        }
    }
}
