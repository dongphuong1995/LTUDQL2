﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample
{
    /// <summary>
    /// Interaction logic for Typography.xaml
    /// </summary>
    public partial class Typography : UserControl
    {
        public Typography()
        {
            InitializeComponent();
        }
    }
}
