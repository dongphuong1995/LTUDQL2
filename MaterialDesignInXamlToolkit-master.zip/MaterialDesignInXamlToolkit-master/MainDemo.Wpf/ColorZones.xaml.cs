﻿using System.Windows.Controls;

namespace MaterialDesignColors.WpfExample
{
    /// <summary>
    /// Interaction logic for ColorZones.xaml
    /// </summary>
    public partial class ColorZones : UserControl
    {
        public ColorZones()
        {
            InitializeComponent();
        }
    }
}
